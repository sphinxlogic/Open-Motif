#include <Mrm/MrmAppl.h>
#include <stdio.h>

extern Widget toplevel;
extern MrmHierarchy hierarchy;

/*
 * create - create a widget hierarchy defined in a UIL module
 */

void
create (w, client_data, call_data)
    Widget w;
    XtPointer client_data;
    XtPointer call_data;
{
    String *args = (String *) client_data;
    String parent_name = args[0];
    Widget parent;

    /* Get a widget id for the parent widget. */
    if (strcmp (parent_name, "toplevel") != 0)
        parent = XtNameToWidget (toplevel, parent_name);
    else
        parent = toplevel;

    /* If the parent was found try to create the hierarchy. */
    if (parent == NULL)
      {
        fprintf (stderr, "create: No such widget `%s'\n", args[0]);
      }
    else
      {
        String child_name = args[1];
        Widget new_w;
        Cardinal status;
        MrmType class;
 
        status = MrmFetchWidget (hierarchy, child_name, parent, &new_w, &class);

        if (status != MrmSUCCESS)
            fprintf (stderr, "Failed to create hierarchy `%s'\n", child_name);
      }

    /* After the widget is created, this callback can be removed. */
    XtRemoveCallback (w, XmNactivateCallback, create, client_data);
}
