#include <stdio.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include <Xm/Xm.h>
#include <Mrm/MrmPublic.h>

void file_exit_activate();

static char	*files[] = {
	"testing.uid"
	};

static MrmRegisterArg bound_names[] = {
  /* menu choices */
  {"file_exit_activate", 	(caddr_t) file_exit_activate}
};

int main (argc, argv)
unsigned int 	argc;
char 		*argv[];

{
  Widget 	toplevel, main_window = NULL;
  Arg		args[10];
  int		n;
  XtAppContext	app_context;
  MrmHierarchy	hierarchy;
  MrmType       class;

  XtSetLanguageProc (NULL, (XtLanguageProc)NULL, NULL);

  MrmInitialize();

  n = 0;
  XtSetArg (args[n], XmNallowShellResize, True); n++;
  toplevel = XtAppInitialize (&app_context, "XMtest", NULL, 0,
			      &argc, argv, NULL, args, n);

  if ( MrmOpenHierarchyPerDisplay (XtDisplay (toplevel),
				   XtNumber (files), files, NULL, 
				   &hierarchy) != MrmSUCCESS) {
    printf ("Can't open hierarchy\n");
    exit (1);
  }

  if ( MrmRegisterNames (bound_names, XtNumber (bound_names)) != MrmSUCCESS ) {
    printf ("Can't register names\n");
    exit (1);
  }

  if ( MrmFetchWidget (hierarchy, "main_window", toplevel, &main_window, 
		       &class) != MrmSUCCESS ) {
    printf ("Can't fetch %s\n", "main_window");
    exit (1);
  }

  XtManageChild (main_window);

  XtRealizeWidget (toplevel);
  XtAppMainLoop (app_context);

}

/*ARGSUSED*/
void file_exit_activate (widget, client_data, call_data)
Widget		widget;
XtPointer	client_data;
XtPointer	call_data;
{
  exit (0);
}   

