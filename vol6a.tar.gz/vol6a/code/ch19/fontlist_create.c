/* fontlist.c -- demonstrate how to create, add to, and destroy
 * font lists.  The fonts and text displayed are hardcoded in
 * this program and cannot be overriden by user resources.
 */
#include <Xm/Label.h>

main(argc, argv)
char *argv[];
{
    Widget        	toplevel;
    XtAppContext  	app;
    XmString      	s1, s2, s3, text, tmp;
    XFontStruct         *font1, *font2, *font3;
    XmFontListEntry	entry1, entry2, entry3;
    XmFontList    	fontlist;
    String        	string1 = "This is a string ",
                  	string2 = "that contains three ",
                  	string3 = "separate fonts.";

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos", NULL, 0,
        &argc, argv, NULL, NULL);

    font1 = XLoadQueryFont (XtDisplay (toplevel), 
        "-*-courier-*-r-*--*-120-*");
    font2 = XLoadQueryFont (XtDisplay (toplevel), 
        "-*-courier-bold-o-*--*-140-*");
    font3 = XLoadQueryFont (XtDisplay (toplevel), 
        "-*-courier-medium-r-*--*-180-*");

    entry1 = XmFontListEntryCreate ("TAG1", XmFONT_IS_FONT, font1);
    entry2 = XmFontListEntryCreate ("TAG2", XmFONT_IS_FONT, font2);
    entry3 = XmFontListEntryCreate ("TAG3", XmFONT_IS_FONT, font3);
    fontlist = XmFontListAppendEntry (NULL, entry1);
    fontlist = XmFontListAppendEntry (fontlist, entry2);
    fontlist = XmFontListAppendEntry (fontlist, entry3);
    XmFontListEntryFree (&entry1);
    XmFontListEntryFree (&entry2);
    XmFontListEntryFree (&entry3);

    s1 = XmStringCreate (string1, "TAG1");
    s2 = XmStringCreate (string2, "TAG2");
    s3 = XmStringCreate (string3, "TAG3");

    /* concatenate the 3 strings on top of each other, but we can only
     * do two at a time.  So do s1 and s2 onto tmp and then do s3.
     */
    tmp = XmStringConcat (s1, s2);
    text = XmStringConcat (tmp, s3);

    XtVaCreateManagedWidget ("label", xmLabelWidgetClass, toplevel,
        XmNlabelString,     text,
        XmNfontList,        fontlist,
        NULL);

    XmStringFree (s1);
    XmStringFree (s2);
    XmStringFree (s3);
    XmStringFree (tmp);
    XmStringFree (text);
    XmFontListFree (fontlist);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}
