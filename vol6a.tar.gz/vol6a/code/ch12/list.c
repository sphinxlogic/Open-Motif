/* simple_list.c -- introduce the List widget.  Lists present
 * a number of comound strings as choices.  Therefore, strings
 * must be converted before set in lists.  Also, the number of
 * visible items must be set or the List defaults to 1 item.
 */
#include <Xm/List.h>

char *months[] = {
    "January", "February", "March", "April", "May", "June", "July",
    "August", "September", "October", "November", "December"
};

main(argc, argv)
int argc;
char *argv[];
{
    Widget           toplevel, list;
    XtAppContext     app;
    int              i, n = XtNumber (months);
    XmStringTable    str_list;
    void             callback();

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos", NULL, 0,
        &argc, argv, NULL, NULL);

    str_list = (XmStringTable) XtMalloc (n * sizeof (XmString *));

    for (i = 0; i < n; i++)
        str_list[i] = XmStringCreateLocalized (months[i]);

    list = XtVaCreateManagedWidget ("Hello",
        xmListWidgetClass,     toplevel,
        XmNvisibleItemCount,   n,
        XmNitemCount,          n,
        XmNitems,              str_list,
	XmNselectionPolicy,    XmMULTIPLE_SELECT,
        NULL);

    XtAddCallback (list, XmNsingleSelectionCallback, callback, NULL);
    XtAddCallback (list, XmNmultipleSelectionCallback, callback, NULL);
    XtAddCallback (list, XmNextendedSelectionCallback, callback, NULL);
    XtAddCallback (list, XmNbrowseSelectionCallback, callback, NULL);

    for (i = 0; i < n; i++)
        XmStringFree (str_list[i]);
    XtFree (str_list);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}

void
callback (widget, client_data, call_data)
Widget widget;
XtPointer client_data;
XtPointer call_data;
{
    XmListCallbackStruct *cbs = (XmListCallbackStruct *) call_data;
    XButtonEvent *bevent = (XButtonEvent *) cbs->event;

    printf ("Called\n");

    printf ("Position: %d\n", XmListYToPos (widget, bevent->y));
}



