/* file_menu.c -- demonstrate how to create a menu bar and pulldown
 * menu using the Motif creation routines.
 */
#include <Xm/RowColumn.h>
#include <Xm/MainW.h>
#include <Xm/CascadeB.h>
#include <Xm/SeparatoG.h>
#include <Xm/PushBG.h>

main(argc, argv)
int argc;
char *argv[];
{
    Widget toplevel, MainWindow, MenuBar, FilePullDown;
    XmString    label_str;
    XtAppContext app;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos", NULL, 0,
        &argc, argv, NULL, NULL);

    MainWindow = XtVaCreateManagedWidget ("main_w",
        xmMainWindowWidgetClass, toplevel,
        XmNscrollingPolicy,  XmAUTOMATIC,
        NULL);

    MenuBar = XmCreateMenuBar (MainWindow, "MenuBar", NULL, 0); 

    /* create the "File" Menu */
    FilePullDown = XmCreatePulldownMenu (MenuBar, "FilePullDown", NULL, 0);

    /* create the "File" button (attach Menu via XmNsubMenuId) */
    label_str = XmStringCreateLocalized ("File");
    XtVaCreateManagedWidget ("File", 
        xmCascadeButtonWidgetClass, MenuBar,
        XmNlabelString,  label_str,
        XmNmnemonic,    'F',
        XmNsubMenuId,    FilePullDown,
        NULL);
    XmStringFree (label_str); 

    /* Now add the menu items */
    XtVaCreateManagedWidget ("Open",
        xmPushButtonGadgetClass, FilePullDown, NULL);

    XtVaCreateManagedWidget ("Save",
        xmPushButtonGadgetClass, FilePullDown, NULL);

    XtVaCreateManagedWidget ("separator",
        xmSeparatorGadgetClass, FilePullDown, NULL);

    XtVaCreateManagedWidget ("Exit",
        xmPushButtonGadgetClass, FilePullDown, NULL);

    XtManageChild (MenuBar);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}
