/* form.c -- demonstrate how fractionBase and XmATTACH_POSITIONs
 * work in Form widgets.
 */
#include <Xm/PushB.h>
#include <Xm/Form.h>

main(argc, argv)
int argc;
char *argv[];
{
    XtAppContext app;
    Widget toplevel, parent, pb1, pb2;
    int x, y;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos", NULL, 0,
        &argc, argv, NULL, NULL);

    parent = XtVaCreateManagedWidget ("form", 
        xmFormWidgetClass, toplevel,
        XmNfractionBase,    5,
        NULL);

    pb1 = XtVaCreateManagedWidget("One",
        xmPushButtonWidgetClass, parent,
	XmNtopAttachment,    XmATTACH_POSITION,
        XmNtopPosition,      1,
        XmNleftAttachment,   XmATTACH_POSITION,
        XmNleftPosition,     1,
        XmNrightAttachment,  XmATTACH_POSITION,
        XmNrightPosition,    4,
        XmNbottomAttachment, XmATTACH_POSITION,
        XmNbottomPosition,   2,
        NULL);

    pb2 = XtVaCreateManagedWidget("Two",
        xmPushButtonWidgetClass, parent,
	XmNtopAttachment,    XmATTACH_POSITION,
        XmNtopPosition,      3,
        XmNleftAttachment,   XmATTACH_POSITION,
        XmNleftPosition,     1,
        XmNrightAttachment,  XmATTACH_POSITION,
        XmNrightPosition,    4,
        XmNbottomAttachment, XmATTACH_POSITION,
        XmNbottomPosition,   4,
        NULL);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}
