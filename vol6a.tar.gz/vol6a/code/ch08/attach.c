/* attach.c -- demonstrate how attachments work in Form widgets. */

#include <Xm/PushB.h>
#include <Xm/Form.h>

main(argc, argv)
int argc;
char *argv[];
{
    Widget toplevel, parent, one, two, three;
    XtAppContext app;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos", NULL, 0,
        &argc, argv, NULL, NULL);

    parent = XtVaCreateManagedWidget ("form",
        xmFormWidgetClass, toplevel, NULL);
    one = XtVaCreateManagedWidget ("One",
        xmPushButtonWidgetClass, parent,
        XmNtopAttachment,   XmATTACH_FORM,
        XmNleftAttachment,  XmATTACH_FORM,
        NULL);
    two = XtVaCreateManagedWidget ("Two",
        xmPushButtonWidgetClass, parent,
        XmNleftAttachment,  XmATTACH_WIDGET,
        XmNleftWidget,      one,
        /* attach top of widget to same y coordinate as top of "one" */
        XmNtopAttachment,   XmATTACH_OPPOSITE_WIDGET,
        XmNtopWidget,       one,
        NULL);
    three = XtVaCreateManagedWidget ("Three",
        xmPushButtonWidgetClass, parent,
        XmNtopAttachment,   XmATTACH_WIDGET,
        XmNtopWidget,       one,
        /* attach left of widget to same x coordinate as left side of "one" */
        XmNleftAttachment,  XmATTACH_OPPOSITE_WIDGET,
        XmNleftWidget,      one,
        NULL);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}
