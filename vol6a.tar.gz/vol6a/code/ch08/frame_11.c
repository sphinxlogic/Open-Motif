/* frame.c -- demonstrate the Frame widget.
 * Create 4 Labels each with a Frame widget as its parent.
 */
#include <Xm/LabelG.h>
#include <Xm/RowColumn.h>
#include <Xm/Frame.h>

main(argc, argv)
int argc;
char *argv[];
{
    Widget toplevel, rowcol, frame;
    XtAppContext app;

    XtSetLanguageProc (NULL, NULL, NULL);

    /* Initialize toolkit and create TopLevel shell widget */
    toplevel = XtVaAppInitialize (&app, "Demos",
        NULL, 0, &argc, argv, NULL, NULL);

    /* Make a RowColumn to contain all the Frames */
    rowcol = XtVaCreateWidget ("rowcolumn",
        xmRowColumnWidgetClass, toplevel,
        XmNspacing, 5,
        NULL);

    /* Create different Frames each containing a unique shadow type */
    XtVaCreateManagedWidget ("Frame Types:",
        xmLabelGadgetClass, rowcol, NULL);
    frame = XtVaCreateManagedWidget ("frame1",
        xmFrameWidgetClass, rowcol,
        XmNshadowType,      XmSHADOW_IN,
        NULL);
    XtVaCreateManagedWidget ("XmSHADOW_IN", 
        xmLabelGadgetClass, frame, 
        NULL); 

    frame = XtVaCreateManagedWidget ("frame2",
        xmFrameWidgetClass, rowcol,
        XmNshadowType,      XmSHADOW_OUT,
        NULL);
    XtVaCreateManagedWidget ("XmSHADOW_OUT", 
        xmLabelGadgetClass, frame, 
        NULL);

    frame = XtVaCreateManagedWidget ("frame3",
        xmFrameWidgetClass, rowcol,
        XmNshadowType,      XmSHADOW_ETCHED_IN,
        NULL);
    XtVaCreateManagedWidget ("XmSHADOW_ETCHED_IN", 
        xmLabelGadgetClass, frame, 
	NULL);

    frame = XtVaCreateManagedWidget ("frame4",
        xmFrameWidgetClass, rowcol,
        XmNshadowType,      XmSHADOW_ETCHED_OUT,
        NULL);
    XtVaCreateManagedWidget ("XmSHADOW_ETCHED_OUT", 
        xmLabelGadgetClass, frame, 
        NULL);

    XtManageChild (rowcol);
    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}

