/* simple_text.c -- Create a minimally configured Text widget */
#include <Xm/Text.h>

main(argc, argv)
int argc;
char *argv[];
{
    Widget        toplevel, st;
    XtAppContext  app;
    char *text = "This is a multiline Text widget.\nIt contains two lines.";
    Arg args[10];
    int n = 0;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos",
        NULL, 0, &argc, argv, NULL, NULL);

    XtSetArg (args[n], XmNeditMode, XmMULTI_LINE_EDIT); n++; 
    st = XmCreateScrolledText (toplevel, "text", args, n);
    XmTextSetString (st, text);

    XtManageChild (st);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}
