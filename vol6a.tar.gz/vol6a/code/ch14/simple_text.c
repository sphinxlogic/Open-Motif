/* simple_text.c -- Create a minimally configured Text widget */
#include <Xm/Text.h>

main(argc, argv)
int argc;
char *argv[];
{
    Widget        toplevel;
    XtAppContext  app;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos",
        NULL, 0, &argc, argv, NULL, NULL);

    XtVaCreateManagedWidget ("text", xmTextWidgetClass, toplevel,
        XmNvalue,     "Now is the time...",
        NULL);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}
