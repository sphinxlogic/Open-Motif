/* tick_marks.c -- demonstrate a scale widget with tick marks. */

#include <Xm/Scale.h>
#include <Xm/LabelG.h>

#define MAX_VAL 10 /* arbitrary value */

main(argc, argv)
int argc;
char *argv[];
{
    Widget        toplevel, scale;
    XtAppContext  app;
    int           i;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos", NULL, 0,
        &argc, argv, NULL, NULL);

    scale = XtVaCreateManagedWidget ("load",
        xmScaleWidgetClass, toplevel,
        XtVaTypedArg,     XmNtitleString, XmRString, "Process Load", 13,
        XmNmaximum,       MAX_VAL * 100,
        XmNminimum,       100,
        XmNvalue,         100,
        XmNdecimalPoints, 2,
        XmNshowValue,     True,
        NULL);
 
    for (i = 0; i < MAX_VAL; i++)
        XtVaCreateManagedWidget ("-", xmLabelGadgetClass, scale, NULL);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}
