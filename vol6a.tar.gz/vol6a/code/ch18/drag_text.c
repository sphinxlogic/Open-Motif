/* drag_text.c -- demonstrate simple use of XmNactivateCallback
 * for Text widgets.  Create a rowcolumn that has rows of Form
 * widgets, each containing a Label and a Text widget.  When
 * the user presses Return, print the value of the text widget
 * and move the focus to the next text widget.
 */
#include <Xm/TextF.h>
#include <Xm/Label.h>
#include <Xm/Form.h>
#include <Xm/RowColumn.h>
#include <Xm/Screen.h>
#include <Xm/DragDrop.h>

char *labels[] = { "Name:", "Address:", "City:", "State:", "Zip:" };
void DoNothing();

static char dragTranslations[] = 
     "#override <Btn2Down>: DoNothing()";

static XtActionsRec dragActions[] = 
     { {"DoNothing", (XtActionProc) DoNothing} };

main(argc, argv)
int argc;
char *argv[];
{
    Widget        toplevel, text_w, form, rowcol, screen, drag_icon;
    XtAppContext  app;
    Arg           args[10];
    XtTranslations parsed_trans;
    int           n, i;
    Pixmap        icon, mask;
    Pixel         fg, bg;
    unsigned int  width, height, depth, junk;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos",
        NULL, 0, &argc, argv, NULL, NULL);

    rowcol = XtVaCreateWidget ("rowcol",
        xmRowColumnWidgetClass, toplevel, NULL);

    parsed_trans = XtParseTranslationTable (dragTranslations); 
    XtAppAddActions (app, dragActions, XtNumber (dragActions));

    for (i = 0; i < XtNumber (labels); i++) {
        form = XtVaCreateWidget ("form", xmFormWidgetClass, rowcol,
            XmNfractionBase,  10,
            NULL);
        XtVaCreateManagedWidget (labels[i],
            xmLabelWidgetClass, form,
/*            XmNtranslations,     parsed_trans,*/
            XmNtopAttachment,    XmATTACH_FORM,
            XmNbottomAttachment, XmATTACH_FORM,
            XmNleftAttachment,   XmATTACH_FORM,
            XmNrightAttachment,  XmATTACH_POSITION,
            XmNrightPosition,    3,
            XmNalignment,        XmALIGNMENT_END,
            NULL);
        text_w = XtVaCreateManagedWidget ("text_w",
            xmTextFieldWidgetClass, form,
	    XmNvalue,            "test",
	    XmNeditable,         False,
            XmNrightAttachment,  XmATTACH_FORM,
            XmNleftAttachment,   XmATTACH_POSITION,
            XmNleftPosition,     4,
            NULL);
        XtManageChild (form);
	n = 0;
	XtSetArg (args[n], XmNdropSiteActivity, XmDROP_SITE_INACTIVE); n++;
	XmDropSiteUpdate (text_w, args, n);
    }
    XtManageChild (rowcol);

    XtVaGetValues (rowcol,
        XmNforeground, &fg,
        XmNbackground, &bg,
        NULL);
    screen = XmGetXmScreen (XtScreen (rowcol));
    icon = XmGetPixmap (XtScreen (rowcol), "text.xbm", fg, bg);
    XGetGeometry (XtDisplay (rowcol), icon, (Window *) &junk,
        (int *) &junk, (int *) &junk, &width, &height, &junk, &depth);

    n = 0;
    XtSetArg (args[n], XmNhotX, 0); n++;
    XtSetArg (args[n], XmNhotY, 0); n++;
    XtSetArg (args[n], XmNwidth, width); n++;
    XtSetArg (args[n], XmNheight, height); n++;
    XtSetArg (args[n], XmNdepth, depth); n++;
    XtSetArg (args[n], XmNpixmap, icon); n++;
    XtSetArg (args[n], XmNforeground, fg); n++;
    XtSetArg (args[n], XmNbackground, bg); n++;
    drag_icon = XmCreateDragIcon (rowcol, "drag_icon", args, n);

    n = 0;
    XtSetArg (args[n], XmNdefaultSourceCursorIcon, drag_icon); n++;
    XtSetValues (screen, args, n);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}

void 
DoNothing(widget, event, params, num_params)
Widget  widget;
XEvent  *event;
String *params;
Cardinal *num_params;
{
}
