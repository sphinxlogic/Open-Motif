/* hello.c -- your typical Hello World program using
 * an InformationDialog.
 */
#include <Xm/MessageB.h>
#include <Xm/PushB.h>

void
pushed(w)
Widget w;
{
    Widget dialog;
    extern void ok_pushed(), cancel_pushed(), help_pushed();
    Arg args[5];
    int n = 0;
    XmString m = XmStringCreateLocalized ("This is a message.");
    XmString t = XmStringCreateLocalized ("Message");

    XtSetArg(args[n], XmNautoUnmanage, False); n++;
    XtSetArg(args[n], XmNmessageString, m); n++;
    XtSetArg(args[n], XmNdialogTitle, t); n++;
    dialog = XmCreateMessageDialog(w, "notice", args, n);
    XtAddCallback(dialog, XmNokCallback, ok_pushed, "Hi");
    XtAddCallback(dialog, XmNcancelCallback, cancel_pushed, "Foo");
    XtAddCallback(dialog, XmNhelpCallback, help_pushed, NULL);
    XmStringFree (m);
    XmStringFree (t);
    
    XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_CANCEL_BUTTON));
    XtUnmanageChild (XmMessageBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));

    XtManageChild(dialog);
    XtPopup(XtParent(dialog), XtGrabNone);
}

main(argc, argv)
int argc;
char *argv[];
{
    XtAppContext app;
    Widget toplevel, pb;

    toplevel = XtVaAppInitialize(&app, "Demos", NULL, 0,
        &argc, argv, NULL, NULL);
    pb = XtVaCreateManagedWidget("Button",
        xmPushButtonWidgetClass, toplevel, NULL);
    XtAddCallback(pb, XmNactivateCallback, pushed, NULL);

    XtRealizeWidget(toplevel);
    XtAppMainLoop(app);
}

void
ok_pushed(w, client_data, reason)
Widget w;
XtPointer client_data;
XmAnyCallbackStruct *reason;
{
    printf("OK was selected: %s\n", client_data);
    XtDestroyWidget(w);
}

void
cancel_pushed(w, client_data, reason)
Widget w;
XtPointer client_data;
XmAnyCallbackStruct *reason;
{
    printf("Cancel was selected: %s\n", client_data);
    XtDestroyWidget(w);
}

void
help_pushed(w, client_data, reason)
Widget w;
XtPointer client_data;
XmAnyCallbackStruct *reason;
{
    puts("Help was selected");
}
