/* hello.c -- your typical Hello World program using
 * an InformationDialog.
 */
#include <Xm/MessageB.h>
#include <Xm/PushB.h>

/*
 * WarningMsg() -- Inform the user that she is about to embark on a
 * dangerous mission and give her the opportunity to back out.
 */
void
WarningMsg(parent, client_data, call_data)
Widget parent;
XtPointer client_data;
XtPointer call_data;
{
    static Widget dialog;
    XmString text, ok_str, cancel_str;
    char *msg = (char *) client_data;

    if (!dialog)
        dialog = XmCreateWarningDialog (parent, "warning", NULL, 0);
    text = XmStringCreateLtoR (msg, XmFONTLIST_DEFAULT_TAG);
    ok_str = XmStringCreateLocalized ("Yes");
    cancel_str = XmStringCreateLocalized ("No");
    XtVaSetValues (dialog,
        XmNmessageString,     text,
        XmNokLabelString,     ok_str,
        XmNcancelLabelString, cancel_str,
        XmNdefaultButtonType, XmDIALOG_CANCEL_BUTTON,
        NULL);
    XmStringFree (text);
    XmStringFree (ok_str);
    XmStringFree (cancel_str);

    XtManageChild (dialog);
    XtPopup (XtParent (dialog), XtGrabNone);
}


main(argc, argv)
int argc;
char *argv[];
{
    XtAppContext app;
    Widget toplevel, pb;

    toplevel = XtVaAppInitialize(&app, "Demos", NULL, 0,
        &argc, argv, NULL, NULL);
    pb = XtVaCreateManagedWidget("Button",
        xmPushButtonWidgetClass, toplevel, NULL);
    XtAddCallback(pb, XmNactivateCallback, WarningMsg, "Do you really want to delete all files?");

    XtRealizeWidget(toplevel);
    XtAppMainLoop(app);
}
