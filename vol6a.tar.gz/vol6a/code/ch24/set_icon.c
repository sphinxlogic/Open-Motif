void
set_icon (wmshell, hierarchy, icon_name)
    Widget wmshell;
    MrmHierarchy hierarchy;
    String icon_name;
{
  Pixmap pixmap;
  Dimension dont_care;    /* for width and height return values */
  Cardinal status;

  status = MrmFetchBitmapLiteral (hierarchy, icon_name,
				  XtScreen(wmshell), XtDisplay(wmshell),
				  &pixmap, &dont_care, &dont_care);

  if (status == MrmSUCCESS)
    XtVaSetValues (wmshell, XmNiconPixmap, pixmap, NULL);
}
