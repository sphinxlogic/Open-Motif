/* showuid.c --
 * Program to show the interface defined in a UID file.
 */

#include <stdio.h>
#include <Mrm/MrmAppl.h>

void quit();
void print();

static MrmRegisterArg callback_list[] = {
    { "quit",     (XtPointer) quit },
    { "print",    (XtPointer) print },
  /* Add additional callback procedures here... */
};

typedef struct {
    String root_widget_name;
} app_data_t;

static app_data_t app_data;

static XtResource resources[] = {
    { "root", "Root", XmRString, sizeof(String),
        XtOffsetOf (app_data_t,root_widget_name), XmRString, 
        (XtPointer) "root" },
};

static XrmOptionDescRec options[] = {
    { "-root", "root", XrmoptionSepArg, NULL },
};

void
quit (w, client_data, call_data)
Widget    w;
XtPointer client_data;
XtPointer call_data;
{
    exit (0);
}

void
print (w, client_data, call_data)
Widget    w;
XtPointer client_data;
XtPointer call_data;
{
    char *message = (char *) client_data;
    puts (message);
}

main (argc, argv)
int   argc;
char *argv[];
{
    XtAppContext  app_context;
    Widget        toplevel;
    Widget        root_widget;
    Cardinal      status;
    MrmHierarchy  hierarchy;
    MrmType       class_code;

    XtSetLanguageProc (NULL, NULL, NULL);
  
    MrmInitialize();

    toplevel = XtVaAppInitialize (&app_context, "Demos", options, 
        XtNumber(options), &argc, argv, NULL, NULL);

    XtGetApplicationResources (toplevel, &app_data, resources, 
        XtNumber(resources), NULL, 0);

    /* Check number of args after Xt and App have removed their options. */
    if (argc < 2) {
        fprintf (stderr, 
            "usage: showuid [Xt options] [-root name] uidfiles ...\n");
        exit (1);
    }

    /* Use argc and arv to obtain UID file names from the command line.
       (Most applications use an internal static array of names.) */
    status = MrmOpenHierarchyPerDisplay (XtDisplay (toplevel), argc - 1,
        argv + 1, NULL, &hierarchy);

    if (status != MrmSUCCESS) {
        XtAppError (app_context, "MrmOpenHierarchyPerDisplay failed");
        exit (1);
    }

    MrmRegisterNames (callback_list, XtNumber (callback_list));

    status = MrmFetchWidget (hierarchy, app_data.root_widget_name,
        toplevel, &root_widget, &class_code); 

    if (status != MrmSUCCESS) {
        XtAppError (app_context, "MrmFetchWidget failed");
        exit (1);
    }

    MrmCloseHierarchy (hierarchy);
    
    XtManageChild (root_widget);
    XtRealizeWidget (toplevel);
    
    XtAppMainLoop (app_context);
}
