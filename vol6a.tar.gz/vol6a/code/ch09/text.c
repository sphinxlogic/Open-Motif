/* text.c -- demonstrate the Scrollbar resource values from
 * a ScrolledText object.  This is used as an introductory examination
 * of the resources used by Scrollbars.
 */
#include <Xm/ScrolledW.h>
#include <Xm/Text.h>

main(argc, argv)
int argc;
char *argv[];
{
    Widget        toplevel, sw, text_w;
    XtAppContext  app;
    Arg           args[10];
    int           n = 0;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos",
        NULL, 0, &argc, argv, NULL, NULL);

    XtSetArg (args[n], XmNscrollBarDisplayPolicy, XmAS_NEEDED); n++;
    XtSetArg (args[n], XmNscrollingPolicy, XmAUTOMATIC); n++;
    sw = XmCreateScrolledWindow (toplevel, "sw", args, n);
    XtManageChild (sw);

    n = 0;
    XtSetArg (args[n], XmNrows,      8); n++;
    XtSetArg (args[n], XmNcolumns,   30); n++;
    XtSetArg (args[n], XmNeditMode,  XmMULTI_LINE_EDIT); n++;
    XtSetArg (args[n], XmNwordWrap,  True); n++;
    text_w = XmCreateText (sw, "text_w", args, n);
    XtManageChild (text_w);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}
