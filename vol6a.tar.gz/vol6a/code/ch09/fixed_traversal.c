/* traversal.c -- demonstrate keyboard traversal in a ScrolledWindow 
 * using the XmNtraverseObscuredCallback.
 */
#include <Xm/PushB.h>
#include <Xm/ToggleB.h>
#include <Xm/ScrolledWP.h>
#include <Xm/ScrollBarP.h>
#include <Xm/RowColumn.h>

void
XmScrollVisible(scrw, wid, hor_margin, ver_margin)
Widget          scrw;
Widget          wid;
Dimension       hor_margin, ver_margin;
{
    XmScrolledWindowWidget sw = (XmScrolledWindowWidget) scrw ;
    register 
    Position newx, newy,      /* new workwindow position */
             wx, wy  ;        /* current workwindow position */
    register 
    Dimension tw, th,         /* widget sizes */
              cw, ch ;        /* clipwindow sizes */
    Position dx, dy ;         /* position inside the workwindow */

    /* check param */
    if (!((scrw) && 
          (wid) &&
          (XmIsScrolledWindow(scrw)) &&
          (sw->swindow.ScrollPolicy == XmAUTOMATIC) &&
          (sw->swindow.WorkWindow))) {
        printf ("Error\n");
        return ;
    }

    /* we need to know the position of the widget relative to the topmost
       workwindow (the workwindow of scrw), so we use 2 XtTranslateCoords,
       but since most of the time, this function will be called
       without nested managers, test this case first */
    
    if (XtWindow(XtParent(wid)) == XtWindow((Widget) sw->swindow.WorkWindow)) {
        printf ("Not nested case\n");
        dx = XtX(wid) ;
        dy = XtY(wid) ;
    } else {
        Position src_x, src_y, dst_x, dst_y ;

        printf ("Nested case\n");
        XtTranslateCoords(wid, 0, 0, &src_x, &src_y);
        XtTranslateCoords(sw->swindow.WorkWindow, 0, 0, &dst_x, &dst_y);
        dx = src_x - dst_x ;
        dy = src_y - dst_y ;
    }

    printf ("dx: %d, dy: %d\n", dx, dy);

    /* get the other needed positions and sizes */
    cw = XtWidth((Widget) sw->swindow.ClipWindow) ;
    ch = XtHeight((Widget) sw->swindow.ClipWindow) ;
    wx = XtX((Widget) sw->swindow.WorkWindow) ;  /* in the clipwindow */
    wy = XtY((Widget) sw->swindow.WorkWindow) ;  /* in the clipwindow */
    tw = XtWidth(wid) ;
    th = XtHeight(wid) ;

    printf ("cw: %d, ch: %d\n", cw, ch);
    printf ("wx: %d, wy: %d\n", wx, wy);
    
    /* find out the zone where the widget lies and set newx,newy (neg) for
       the workw */
    /* if the widget is bigger than the clipwindow, we put it on
       the left, top or top/left, depending on the zone it was */

    if (dy < -wy) {                              /* North */
        newy = dy - ver_margin ; /* stuck it on top + margin */
    } else 
    if ((dy < (-wy + ch)) && ((dy + th) <= (-wy + ch))) {
        newy = -wy ;  /* in the middle : don't move y */
    } else {                                     /* South */
        if (th > ch)
            newy = dy - ver_margin ; /* stuck it on top if too big */
        else
            newy = dy - ch + th + ver_margin;
    } 
    

    if (dx < -wx) {                              /* West */
        newx = dx - hor_margin ; /* stuck it on left + margin */
    } else
    if ((dx < (-wx + cw)) && ((dx + tw) <= (-wx + cw))) {
        newx = -wx ;  /* in the middle : don't move x */
    } else {                                     /* East */
        if (tw > cw)
            newx = dx - hor_margin ; /* stuck it on left if too big */
        else
            newx = dx - cw + tw + hor_margin;
    } 

    printf ("newx: %d\n", newx);
    printf ("newy: %d\n", newy);

    /* we also have to test that because the margins can be huge */
    if (newx < 0) newx = 0 ;
    if (newy < 0) newy = 0 ;
    if (newx > (XtWidth((Widget) sw->swindow.WorkWindow) - cw)) 
        newx = XtWidth((Widget) sw->swindow.WorkWindow) - cw ;
    if (newy > (XtHeight((Widget) sw->swindow.WorkWindow) - ch)) 
        newy = XtHeight((Widget) sw->swindow.WorkWindow) - ch ;

    printf ("newx: %d\n", newx);
    printf ("newy: %d\n", newy);

    /* move the workwindow, and make the widget appears if not yet visible */
    if (newx != -wx) 
        XmScrollBarSetValues((Widget)sw->swindow.hScrollBar, newx, 
                         sw->swindow.hScrollBar->scrollBar.slider_size, 
                         sw->swindow.hScrollBar->scrollBar.increment, 
                         sw->swindow.hScrollBar->scrollBar.page_increment, 
                         True);
    if (newy != -wy)
        XmScrollBarSetValues((Widget)sw->swindow.vScrollBar, newy, 
                         sw->swindow.vScrollBar->scrollBar.slider_size, 
                         sw->swindow.vScrollBar->scrollBar.increment, 
                         sw->swindow.vScrollBar->scrollBar.page_increment, 
                         True);
}

main(argc, argv)
int argc;
char *argv[];
{
    Widget toplevel, sw, rc;
    XtAppContext app;
    void traverse();
    int i;
    char name[10];

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "Demos", NULL, 0, 
        &argc, argv, NULL, NULL);

    sw = XtVaCreateManagedWidget ("scrolled_w",
        xmScrolledWindowWidgetClass, toplevel,
        XmNscrollingPolicy, XmAUTOMATIC,
        NULL);

    XtAddCallback (sw, XmNtraverseObscuredCallback, traverse, NULL);

    /* RowColumn is the work window for the widget */
    rc = XtVaCreateWidget ("rc", 
        xmRowColumnWidgetClass, sw, 
	XmNorientation, XmHORIZONTAL,
        XmNpacking, XmPACK_COLUMN,
	XmNnumColumns, 10,
        NULL);

    for ( i = 0; i < 10; i++ ) {
        sprintf (name, "Toggle %d", i);
        XtVaCreateManagedWidget (name, xmToggleButtonWidgetClass, rc, NULL);
        sprintf (name, "Button %d", i);
        XtVaCreateManagedWidget (name, xmPushButtonWidgetClass, rc, NULL);
    }
    XtManageChild (rc);

    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}

void
traverse(widget, client_data, call_data)
Widget widget;
XtPointer client_data;
XtPointer call_data;
{
    XmTraverseObscuredCallbackStruct *cbs = 
        (XmTraverseObscuredCallbackStruct *) call_data;

    XmScrollVisible (widget, cbs->traversal_destination, 10, 10);
}

